# STARTRACE — Algol Pilot Audit

## Data
- Target: Algol
- Source file: data/processed/Algol_clean.csv
- Columns: time_btjd, normalized_flux
- Observations: 13,247
- Time span: approximately BTJD 1790.66–1814.30
- Median cadence: approximately 2 minutes

## Quality checks
- Cadence gaps are present and must be respected.
- The light curve contains multiple low-flux intervals.
- Threshold-based candidates are exploratory, not confirmed eclipses.
- Candidate fragments may split one broad feature into multiple runs.
- No physical period or event classification has been established by this audit.

## Model limitations
- Autoencoder reconstruction error is not an event probability or confidence score.
- Randomly splitting overlapping windows can inflate validation performance.
- Generalization must be tested on targets excluded entirely from training.

## Next steps
1. Verify target metadata and event labels against independent catalogues.
2. Define reproducible event windows and negative examples.
3. Build a labelled dataset with target-level train/validation/test separation.
4. Compare simple baselines with a 1D CNN if the dataset supports it.
5. Report precision, recall, F1, PR-AUC, and held-out-target performance.
