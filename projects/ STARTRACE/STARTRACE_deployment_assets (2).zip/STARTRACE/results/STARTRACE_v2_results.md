# STARTRACE v2 — Masked Denoising Experiment

## Method
A convolutional denoising autoencoder was trained using existing 256-point
windows. Training inputs received Gaussian noise and one masked segment.
No new data were downloaded; the original model and artifacts were preserved.

## Evaluation
Both models were compared against the clean target on temporal validation
windows from the three training stars and on held-out RR Lyrae windows.
Metrics include MAE, Pearson correlation, and percentage of signal variation
retained.

## Limitations
The dataset contains only four stars. Windows overlap, and RR Lyrae's updated
PDCSAP preprocessing has not yet been propagated into X_windows.npy.
Results are preliminary and do not establish confirmed astrophysical discoveries.

## Results
|                                                                            |   MAE_vs_clean |   correlation_vs_clean |   std_retained_pct |
|:---------------------------------------------------------------------------|---------------:|-----------------------:|-------------------:|
| ('held_out_RR_Lyr', 'RR_Lyr', 'clean_input', 'denoising_v2')               |         0.0158 |                 0.9991 |            98.9558 |
| ('held_out_RR_Lyr', 'RR_Lyr', 'clean_input', 'original')                   |         0.1051 |                 0.9868 |           103.494  |
| ('held_out_RR_Lyr', 'RR_Lyr', 'masked_noisy_input', 'denoising_v2')        |         0.1092 |                 0.9604 |            96.1435 |
| ('held_out_RR_Lyr', 'RR_Lyr', 'masked_noisy_input', 'original')            |         0.2007 |                 0.9123 |            97.9142 |
| ('temporal_validation', 'Algol', 'clean_input', 'denoising_v2')            |         0.0182 |                 0.9971 |            97.0049 |
| ('temporal_validation', 'Algol', 'clean_input', 'original')                |         0.1136 |                 0.8941 |           103.186  |
| ('temporal_validation', 'Algol', 'masked_noisy_input', 'denoising_v2')     |         0.0853 |                 0.8504 |           104.525  |
| ('temporal_validation', 'Algol', 'masked_noisy_input', 'original')         |         0.1715 |                 0.6938 |           115.6    |
| ('temporal_validation', 'HD_209458', 'clean_input', 'denoising_v2')        |         0.0222 |                 0.9993 |            99.3695 |
| ('temporal_validation', 'HD_209458', 'clean_input', 'original')            |         0.573  |                 0.459  |            46.891  |
| ('temporal_validation', 'HD_209458', 'masked_noisy_input', 'denoising_v2') |         0.1531 |                 0.9194 |            94.1236 |
| ('temporal_validation', 'HD_209458', 'masked_noisy_input', 'original')     |         0.5961 |                 0.4074 |            46.1063 |
| ('temporal_validation', 'TOI_700', 'clean_input', 'denoising_v2')          |         0.0232 |                 0.9994 |            99.4627 |
| ('temporal_validation', 'TOI_700', 'clean_input', 'original')              |         0.6776 |                 0.4598 |            45.5268 |
| ('temporal_validation', 'TOI_700', 'masked_noisy_input', 'denoising_v2')   |         0.156  |                 0.933  |            94.0717 |
| ('temporal_validation', 'TOI_700', 'masked_noisy_input', 'original')       |         0.6916 |                 0.4277 |            43.3019 |