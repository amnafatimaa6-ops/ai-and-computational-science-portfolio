# STARTRACE — Research Pilot Final Report

**Report date:** 2026-10-12

## Research question
Can a convolutional denoising model learn useful representations of existing
TESS light-curve windows, and do the resulting groups capture measurable
signal properties?

## Data and scope
- Existing windows: 1158
- Targets: Algol, HD_209458, RR_Lyr, TOI_700
- No additional data downloaded for this analysis.
- Four targets are insufficient to establish broad astronomical generalization.

## Model
A convolutional masked-denoising autoencoder was trained to reconstruct
existing windows corrupted with noise and a masked segment. The original
autoencoder was preserved.

## Reconstruction evaluation
See `startrace_v2_final_evaluation_summary.csv` for MAE, correlation,
variation retained, input condition, and evaluation split.

These are reconstruction metrics, not evidence of new astronomical discoveries.
The validation windows are temporally separated from training windows, but
independence and preprocessing must still be treated cautiously.

## Learned representations and clustering
- Embedding size: 32
- K-means groups: 4
- Original embedding-cluster silhouette: 0.311
- Handcrafted-feature clustering and partition agreement are in
  `startrace_cluster_method_comparison.csv`.
- Cluster feature summaries and target composition are saved separately.
- Representative waveforms and PCA plots are saved in `results/`.

Silhouette measures geometric separation, not astrophysical validity. Cluster
membership may reflect target identity, preprocessing, noise, or morphology.

## Limitations
1. Only four stars are represented.
2. Adjacent windows overlap, so windows are not independent samples.
3. RR Lyrae's corrected PDCSAP preprocessing has not been propagated to the
   saved window array used in these experiments.
4. Autocorrelation at a few fixed lags is not a validated period measurement.
5. No independently verified labels or confirmed discoveries were established.
6. Cluster stability across random initializations does not establish scientific
   reproducibility across datasets.

## Conclusion
STARTRACE demonstrates a working exploratory pipeline for light-curve
reconstruction, denoising, learned representations, and unsupervised clustering.
Whether its clusters represent useful, generalizable astrophysical morphology
remains an open question requiring more independent targets and validated labels.

## Reproducibility artifacts
- `startrace_denoising_v2.keras`
- `startrace_v2_model_comparison.csv`
- `startrace_v2_embeddings.npy`
- `startrace_v2_morphology_clusters.csv`
- `startrace_morphology_features.csv`
- `startrace_cluster_method_comparison.csv`
- `startrace_cluster_stability.csv`
- `startrace_cluster_representatives.png`
