# STARTRACE — Research Progress Report

**Generated:** 2026-10-12

## Abstract

STARTRACE is a prototype for investigating machine-learning methods
that learn patterns in stellar light curves. This pilot uses four TESS
targets and a convolutional autoencoder to study reconstruction behavior,
unseen-target transfer, and sensitivity to synthetic data corruption.

The results are exploratory. Independent catalogue labels have not yet
been verified, so the study does not establish supervised classification
accuracy or confirm astronomical events.

## 1. Dataset and quality audit

The pilot contains 1,158 windows of 256 samples across four targets.
The window array contains finite values and the window metadata has no
missing cells.

| target    |   observations | finite   |   duplicate_times |   median_cadence_min |   gaps_over_10min |   flux_min |   flux_median |   flux_max |    flux_std | catalogue_label_verified   |
|:----------|---------------:|:---------|------------------:|---------------------:|------------------:|-----------:|--------------:|-----------:|------------:|:---------------------------|
| HD_209458 |         110897 | True     |                 0 |             0.333328 |                11 |   0.996688 |             1 |    1.00326 | 0.000654298 | False                      |
| TOI_700   |          18279 | True     |                 0 |             2        |                44 |   0.99385  |             1 |    1.0066  | 0.00165584  | False                      |
| Algol     |          13247 | True     |                 0 |             2.00001  |                14 |   0.926054 |             1 |    1.06796 | 0.0161811   | False                      |
| RR_Lyr    |          18292 | True     |                 0 |             2        |                 7 |  -2.83063  |             1 |    7.03466 | 2.12531     | False                      |

**Data limitations:** Catalogue labels and event timings remain
unverified. The RR Lyrae processed series showed an unusually broad
normalized-flux range. Although an official SPOC product was retrieved,
the existing window array and saved evaluation were not regenerated
from the corrected product.

## 2. Reconstruction evaluation

| target    |   windows |   mean_mae |   median_mae |   p95_mae |
|:----------|----------:|-----------:|-------------:|----------:|
| Algol     |        75 |   0.140012 |     0.108399 |  0.273749 |
| HD_209458 |       843 |   0.574601 |     0.571251 |  0.634613 |
| RR_Lyr    |       127 |   0.105099 |     0.106303 |  0.129841 |
| TOI_700   |       113 |   0.668183 |     0.669626 |  0.72088  |

Reconstruction MAE measures the difference between model inputs and
reconstructions. It is not a class probability, calibrated confidence,
or proof of an astronomical event. Target-level differences may reflect
morphology and data-processing differences.

## 3. Held-out target and robustness experiment

| target    | condition               |   windows |   mean_reconstruction_mae |
|:----------|:------------------------|----------:|--------------------------:|
| Algol     | original                |        75 |                  0.140012 |
| HD_209458 | original                |       843 |                  0.574601 |
| RR_Lyr    | original                |       127 |                  0.105099 |
| RR_Lyr    | added_noise_sd_0.1      |       127 |                  0.125147 |
| RR_Lyr    | simulated_missing_20pct |       127 |                  0.254594 |
| TOI_700   | original                |       113 |                  0.668183 |

RR Lyrae was excluded from the autoencoder's training targets, making
this an exploratory held-out-target test. However, its evaluated windows
were generated before the later PDCSAP correction. The robustness tests
use synthetic Gaussian noise and zero-filled missing samples; they do
not represent every real observation condition.

## 4. Objective status

| Objective | Status | Remaining work |
|---|---|---|
| 1. Real dataset | Partial | Verify catalogue associations and labels; regenerate RR Lyrae windows |
| 2. Astrophysical patterns | Partial | Systematic morphology analysis with verified references |
| 3. Model comparison | Partial | Baselines; supervised CNN only if labels support it |
| 4. Unseen-star generalization | Preliminary | Repeat after data correction; evaluate more independent targets |
| 5. Robustness and limitations | Preliminary | Broader corruption tests, error analysis, uncertainty evaluation |
| 6. Reproducible artifact | Partial | End-to-end reproducibility, final figures, report, deployment checks |

## 5. Scientific limitations

- Four targets are insufficient to support broad claims about generalization.
- Overlapping windows are not independent observations.
- Catalogue-derived labels and event timings have not been independently verified.
- No precision, recall, F1-score, or PR-AUC is reported because a verified
  supervised classification evaluation is not yet available.
- Predictions and reconstruction errors must not be described as confirmed
  discoveries.

## 6. Reproducibility artifacts

- `data/processed/X_windows.npy`
- `data/processed/window_metadata.csv`
- `data/processed/pilot_summary.csv`
- `startrace_autoencoder.keras`
- `results/objective1_quality_report.csv`
- `results/model_reconstruction_evaluation.csv`
- `results/generalization_robustness_report.csv`

## Conclusion

STARTRACE has a functioning exploratory autoencoder pipeline and initial
robustness experiments. The next scientific priority is to establish
trustworthy labels and a consistent dataset before attempting supervised
classification. The present results are preliminary and should not be
interpreted as validated astronomical event detection.
